import unittest

from ..src.hikac import get_data_from_ac_event


class HIKACTest(unittest.TestCase):
    def checkItIsWorking(self) -> None:
        print("Working")