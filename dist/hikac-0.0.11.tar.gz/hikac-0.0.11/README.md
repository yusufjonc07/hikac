# HIKAC

This modest python package helps you to get events from HIKVISION AC terminals. 

## Installation

```sh
pip install hikac
